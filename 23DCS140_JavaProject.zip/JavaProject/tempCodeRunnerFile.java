public class expert {
//     String name;
//     int exp;
//     String tech, job, contact, email;

//     public expert() {
//     }

//     public String getName() {
//         return name;
//     }

//     public int getExp() {
//         return exp;
//     }

//     public String getTech() {
//         return tech;
//     }

//     public String getJob() {
//         return job;
//     }

//     public String getContact() {
//         return contact;
//     }

//     public String getEmail() {
//         return email;
//     }

//     public expert(String name, String tech, int exp, String job, String contact, String email) {
//         this.tech = tech;
//         this.name = name;
//         this.exp = exp;
//         this.job = job;
//         this.contact = contact;
//         this.email = email;
//     }

// }
